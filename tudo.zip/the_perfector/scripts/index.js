/*
const idWindows = window.innerWidth;

if(idWindows > 700)
{
    alert("Bem vindo ao The perfector");
}else{
    alert("Bem vindo ao The perfector. Baixe nosso aplicativo para melhor usabilidade");
}
*/